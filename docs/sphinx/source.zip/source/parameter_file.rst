Parameter file: Section details
-------------------------------

.. toctree::
   :maxdepth: 1

   section_parfile/RunMode.md
   section_parfile/ImagE.md
   section_parfile/SourcE.md
   section_parfile/CleanLens.md
   section_parfile/ShapeModel.md
   section_parfile/ShapeLimit.md
   section_parfile/ObserV.md
   section_parfile/Dynfile.md
   section_parfile/GrillE.md
   section_parfile/PoTential.md
   section_parfile/LimiT.md
   section_parfile/PotFile.md
   section_parfile/ClinE.md
   section_parfile/CosmoloGie.md 
