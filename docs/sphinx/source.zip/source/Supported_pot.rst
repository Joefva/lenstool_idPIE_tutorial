Supported Potentials
--------------------

.. toctree::
   :maxdepth: 1

   potentials/NFW.md
   potentials/ExternalShear.md
   potentials/EinastoPotential.md
   potentials/External_maps.md
   potentials/Mass_sheet.md
   potentials/SIS.md
   potentials/PIEMD.md
