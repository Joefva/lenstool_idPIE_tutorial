API
===

# .. autosummary::
#   :toctree: generated

-------------
C Functions
-------------

# .. doxygenfunction:: o_chi_lhood0
