Definining a model
------------------
