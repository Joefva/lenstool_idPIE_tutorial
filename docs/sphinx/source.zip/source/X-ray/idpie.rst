idPIE: Joint baryon and DM modelling
------------------------------------


.. toctree::
   :maxdepth: 1

   usage
   potfile
   tutorial_idpie
