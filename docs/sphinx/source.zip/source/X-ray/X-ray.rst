X-ray extension
-----------------

.. toctree::
   :maxdepth: 1

   general_method_X.md
   idpie
