Installation of Lenstool
------------------------


.. toctree::
   :maxdepth: 1

   installation/installation_general
   installation/CondA.md
   installation/CygwiN.md
