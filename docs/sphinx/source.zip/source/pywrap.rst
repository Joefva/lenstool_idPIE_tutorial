Python wrapper
------------------
